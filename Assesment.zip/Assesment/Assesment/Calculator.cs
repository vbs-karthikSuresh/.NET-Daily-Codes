﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assesment
{
    public partial class Calculator : Form
    {
        Double result;
        String opr;
        bool operationPerformed = false;
        public Calculator()
        {
            InitializeComponent();
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ButtonClick(object sender, EventArgs e)
        {
            if (operationPerformed)
            {
                textBoxResult.Clear();
            }
            Button b = (Button)sender;
            if (b.Text == ".")
            {
                if (!textBoxResult.Text.Contains("."))
                    textBoxResult.Text = textBoxResult.Text + b.Text;
            }
            else
                textBoxResult.Text = textBoxResult.Text + b.Text;
            operationPerformed = false;
        }
       

        private void Clrbtn_Click(object sender, EventArgs e)
        {
            textBoxResult.Text = textBoxResult.Text.Substring(0, textBoxResult.Text.Length - 1);
        }

        private void ClearAllbtn_Click(object sender, EventArgs e)
        {
            textBoxResult.Clear();
            result = 0;
            lblResult.Text = "";
        }
        private void OperatorButton(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (result != 0 && b.Text!="=")
            {
                Equalbtn.PerformClick();
                opr = b.Text;
                result = Double.Parse(textBoxResult.Text);
                lblResult.Text = result + opr;
                operationPerformed = true;
            }
            else if(b.Text!="=")
            {
                opr = b.Text;
                result = Double.Parse(textBoxResult.Text);
                operationPerformed = true;
                lblResult.Text = result + opr;
            }
        }

        private void Equalbtn_Click(object sender, EventArgs e)
        {
            switch (opr)
            {
                case "+":
                    textBoxResult.Text = (result + Double.Parse(textBoxResult.Text)).ToString();
                    break;
                case "-":
                    textBoxResult.Text = (result - Double.Parse(textBoxResult.Text)).ToString();
                    break;
                case "*":
                    textBoxResult.Text = (result * Double.Parse(textBoxResult.Text)).ToString();
                    break;
                case "/":
                    textBoxResult.Text = (result / Double.Parse(textBoxResult.Text)).ToString();
                    break;
                default: break;
            }
            result = 0;
            lblResult.Text = "";
        }
    }
}
