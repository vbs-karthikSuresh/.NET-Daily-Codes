﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;
using System.Speech.Synthesis;

namespace Assesment
{
    
    public partial class StopWatch : Form
    {
        System.Timers.Timer timer;
        int h, m, s, ms;
        SpeechSynthesizer speak;
        public StopWatch()
        {
            InitializeComponent();
        }

        private void Stopbtn_Click(object sender, EventArgs e)
        {
            timer.Stop();
            speak.Speak("Pausing Stopwatch");
        }

        private void Resetbtn_Click(object sender, EventArgs e)
        {
            timer.Stop();
            h = 0;
            m = 0;
            s = 0;
            ms = 0;
            label1.Text = string.Format($"{h}:{m}:{s}:{ms}");
            progressBar1.Value = 0;
            speak.Speak("Resetting Stopwatch");
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void StopWatch_Load(object sender, EventArgs e)
        {
            timer = new System.Timers.Timer();
            timer.Interval = 1;
            timer.Elapsed += OnTimeEvent;
            speak = new SpeechSynthesizer();
            speak.SetOutputToDefaultAudioDevice();
        }

        private void OnTimeEvent(object sender, ElapsedEventArgs e)
        {
            Invoke(new Action(() =>
            {
                ms += 1;
                if (ms == 100)
                {
                    ms = 0;
                    s += 1;
                }
                if (s == 60)
                {
                    s = 0;
                    m += 1;
                }
                if (m == 60)
                {
                    h = 0;
                    m += 1;
                }
                label1.Text = string.Format($"{h}:{m}:{s}:{ms}");
                progressBar1.Value += 1;
            }));
        }

        private void Startbtn_Click(object sender, EventArgs e)
        {
            timer.Start();
            speak.Speak("Starting STopwatch");
        }
    }
}
