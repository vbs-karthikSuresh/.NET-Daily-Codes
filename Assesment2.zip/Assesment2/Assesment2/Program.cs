﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace Assesment2
{
    class Program
    {
        public string IntToRoman(int number)
        {
            return
                new string('I', number)
                    .Replace(new string('I', 1000), "M")
                    .Replace(new string('I', 900), "CM")
                    .Replace(new string('I', 500), "D")
                    .Replace(new string('I', 400), "CD")
                    .Replace(new string('I', 100), "C")
                    .Replace(new string('I', 90), "XC")
                    .Replace(new string('I', 50), "L")
                    .Replace(new string('I', 40), "XL")
                    .Replace(new string('I', 10), "X")
                    .Replace(new string('I', 9), "IX")
                    .Replace(new string('I', 5), "V")
                    .Replace(new string('I', 4), "IV");
        }
        static void Permute(int[] arr, int i, int n)
        {
            int j;
            if (i == n)
            {
                for (j = 0; j <= n; j++)
                {
                    Console.Write(arr[j]);
                }
                Console.WriteLine();
            }
            else
            {
                for (j = i; j <= n; j++)
                {
                    Swap(ref arr[i], ref arr[j]);
                    Permute(arr, i + 1, n);
                    Swap(ref arr[i], ref arr[j]); 
                }
            }
        }

        static void Swap(ref int a, ref int b)
        {
            int tmp;
            tmp = a;
            a = b;
            b = tmp;
        }
        static void Main(string[] args)
        {
            /*
             //First Program
            List<int> arr = new List<int>();
            Console.WriteLine("Input the number of elements to be stored in the array :");
            int len = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements");
            for(int i = 0; i < len; i++)
            {
                arr.Add(Convert.ToInt32(Console.ReadLine()));
            }
            int sum = 0;
            foreach(var item in arr)
            {
                sum += item;
            }
            Console.WriteLine("Sum of all elements stored in the array is : "+sum);
            
            //Second Program
            List<int> arr = new List<int>();
            Console.WriteLine("Input the number of elements to be stored in the array :");
            int len = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements");
            for (int i = 0; i < len; i++)
            {
                arr.Add(Convert.ToInt32(Console.ReadLine()));
            }
            var res = new List<int>();
            int temp = arr[0]; 
            var count = 1;
            for (int i = 1; i < len; i++) 
            {
                if (arr[i] == temp) count++;
                else
                {
                    if (count == 1) res.Add(temp);
                    temp = arr[i];
                    count = 1;
                }
            }
            if (count == 1) res.Add(temp);
            Console.WriteLine("The unique elements found in the array are: ");
            foreach (var item in res)
            {
                Console.WriteLine(item);
            }
            //Third Program
            Console.WriteLine("Input the number of rows in the array :");
            int row = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input the number of columns in the array :");
            int col = Convert.ToInt32(Console.ReadLine());
            int[,] arr=new int[row, col];
            Console.WriteLine("Enter the elements");
            for (int i = 0; i < row; i++)
            {
                for(int j = 0; j < col; j++)
                {
                    arr[i,j]= Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("Printing the array");
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    Console.Write(arr[i, j]+" ");
                }
                Console.WriteLine();
            }

             //Sixth Program
            Console.WriteLine("ENter the number to convert");
            int number= Convert.ToInt32(Console.ReadLine());
            Program p = new Program();
            Console.WriteLine("Roman numerals of the said integer value:");
            Console.WriteLine(p.IntToRoman(number));
            //Seventh Program
            int[] arr = new int[5];
            Console.WriteLine(" Input the number of elements to store in the array [maximum 5 digits ]:");
            int len = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements");
            for (int i = 0; i < len; i++)
            {
                arr[i]=Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine($"The Permutations with a combination of {len} digits are :");
            Permute(arr, 0, len - 1);
             //Fifth Program
            String[] cultureNames = { "en-US", "sv-SE" };
            String[] wordsUS = { "apple",  "bat","music", "art" };
            String[] wordsSE = { "Apple", "Bat", "Music" , "Art" };
            StringComparison[] comparisons = (StringComparison[])Enum.GetValues(typeof(StringComparison));
            foreach (var cultureName in cultureNames)
            {
                Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(cultureName);
                Console.WriteLine("Current Culture: {0}", CultureInfo.CurrentCulture.Name);
                for (int i = 0; i <= wordsUS.GetUpperBound(0); i++)
                {
                    foreach (var comparison in comparisons)
                    {
                        Console.WriteLine($"{wordsUS[i]} = {wordsSE[i]} ({comparison}): {String.Equals(wordsUS[i], wordsSE[i], comparison)}");
                    }
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
            */
            Console.WriteLine("Sign-Up");
            Console.WriteLine("Enter Username");
            string user = Console.ReadLine();
            Console.WriteLine("Enter Password");
            string pass= Console.ReadLine();
            Console.WriteLine("Login");
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Enter Username");
                string user1 = Console.ReadLine();
                Console.WriteLine("Enter Password");
                string pass1 = Console.ReadLine();
                if(user1==user && pass1 == pass)
                {
                    Console.WriteLine("Password entered successfully!");
                    break;
                }
                else
                {
                    Console.WriteLine("Incorrect username or password");
                }
            }
        }
    }
}
