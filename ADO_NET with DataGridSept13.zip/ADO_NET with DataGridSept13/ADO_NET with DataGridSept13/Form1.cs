﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_NET_with_DataGridSept13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void FillData(object sender, EventArgs e)
        {
            /*
            string ConnString = "Data Source=192.168.1.230;Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022";
            SqlConnection connection = new SqlConnection(ConnString);
            connection.Open();
            string querystring = "Select * from karthiks_employee";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring,connection);
            //With data tables
            //DataTable d = new DataTable("employee");
            //adapter.Fill(d);
            //dataGridView1.DataSource = d;
            //With Dataset
            DataSet d = new DataSet("employee");
            adapter.Fill(d, "employee");
            dataGridView1.DataSource = d.Tables[0].DefaultView;
            connection.Dispose();
            connection.Close();
            */
        }
    }
}
