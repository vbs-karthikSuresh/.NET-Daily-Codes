﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Sept13
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string ConnString = "Data Source=192.168.1.230;Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022";
            SqlConnection conn = new SqlConnection(ConnString);
            string querystring = " Select * from karthiks_employee";
            conn.Open();
            SqlCommand cmd = new SqlCommand(querystring, conn);//Running Querystring on the specified connection string 
            SqlDataReader reader = cmd.ExecuteReader();
            //Console.WriteLine(reader); 
            //Console.WriteLine(reader.FieldCount);
            for (int i = 0; i < reader.FieldCount; i++)
            {
                Console.Write(reader.GetName(i)+" ");
                
            }
            Console.WriteLine();
            while (reader.Read())
            {
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    Console.Write(reader[i].ToString() + "\t");
                }
                Console.WriteLine();
                //Console.WriteLine(reader[0].ToString() + " Name is :" + reader[1].ToString() + 
                //    " And Subject is :" + reader[2].ToString() /*+ " " + reader[3].ToString());
            }
            reader.Close();
            conn.Close();
            
            /*
            int[] num = new int[] { 0, 2, 1, 15, 5, 9, 12 };
            var result = from a in num where a < 4 orderby a select a;
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }
            */
            /*
            string[] names =
             {
                "Everyone You Hate Is Going to Die",
                "Before & Laughter",
                "I Can't Make This Up",
                "The New One",
                "The Decision"
            };
            IEnumerable<string> result = from name in names where name.Length > 15 select name;
            foreach(var item in result)
            {
                Console.WriteLine(item);
            }
            */

        }
    }
}
