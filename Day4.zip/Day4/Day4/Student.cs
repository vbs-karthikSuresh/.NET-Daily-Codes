﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    internal class Student
    {
        private string[] names = new string[25];
        public string this[int i]
        {
            get { return names[i]; }
            set { names[i] = value; }
        }
        public int Id { get; set; }//Here private field is automatically declared do this from next time
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}
