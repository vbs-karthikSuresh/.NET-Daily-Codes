﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    internal interface BasicCalculator
    {
        public int Add(int a, int b);
        public int Sub(int a, int b);
    }
    interface ScientificCalculator
    {
        public float Add(int a, int b);
        public float Subtract(float a,float b);
    }
    class Calculation : BasicCalculator, ScientificCalculator
    {
        public int Add(int a, int b)
        {
            return a + b;
        }

        public int Sub(int a, int b)
        {
            return a - b;
        }


        float ScientificCalculator.Add(int a, int b)
        {
            return a + b;
        }

        float ScientificCalculator.Subtract(float a, float b)
        {
            return a-b;
        }
    }
}
