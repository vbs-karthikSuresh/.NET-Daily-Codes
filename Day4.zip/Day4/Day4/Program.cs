﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    
    /*
    class Base
    {
        public string name;
        public int id;
        public Base()
        {
            Console.WriteLine("Base Class");
        }
        public void read(int id, string name)
        {
            this.id = id;
            this.name = name;
            Console.WriteLine(id+" "+name);
        }

    }
    
    class Child: Base
    {
        public Child()
        {
            Console.WriteLine("Child2 Class");
        }
        
    }
    */
    
    
    class Program//: Base
    {
        /*
        public Program()
        {
            Console.WriteLine("Child class");
        }
        */
        static void Main(string[] args)
        {
            /*
            Student s1 = new Student();
            s1.Id = 1;
            s1.Name = "Karthik";
            Console.WriteLine(s1.Name);
            s1[0] = "Martin";
            s1[1] = "Garrix";
            s1[2] = "Jon";
            s1[3] = "Bellion";
            for(int i = 0; i < 4; i++)
            {
                Console.WriteLine(s1[i]);
            }
            */
            /*
            Program p1 = new Program();
            p1.read(1, "Karthik");
            Child c1 = new Child();
            c1.read(2, "Martin");
            */
            Calculation c1 = new Calculation();
            c1.Add(10, 20);
            c1.Add(10.324f, 20.324f);
        }
    }
}
