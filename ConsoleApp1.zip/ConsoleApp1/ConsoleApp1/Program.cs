﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;//We have to add this namespace for text2speech
using System.Globalization;
using System.Threading;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args){
            /*
            Console.WriteLine("Enter Name:");
            string name = Console.ReadLine();
            Console.WriteLine("The name is "+name);
            Console.WriteLine("Enter Age:");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"{age} is the given age");
            */
            /*
              Text to Speech for audio device or a wav file
            
            SpeechSynthesizer speechSynthesizer = new SpeechSynthesizer();
            //speechSynthesizer.SetOutputToDefaultAudioDevice();
            speechSynthesizer.SetOutputToWaveFile("C:\\Users\\Karthik Suresh\\source\\repos\\ConsoleApp1\\karthik.wav");
            Console.WriteLine("Enter text");
            speechSynthesizer.Speak(Console.ReadLine());
            */
            //DateTime date = new DateTime(2001, 1, 31);
            //Console.WriteLine(date.ToString("F"));
            /*
            CultureInfo cultureInfo = new CultureInfo("en-US");
            DateTime dateTime = DateTime.Now;
            string dateinUSA = dateTime.ToString("F", new CultureInfo("en-US"));
            Console.WriteLine(dateinUSA);
            string dateinHindi = dateTime.ToString("F", new CultureInfo("hi-IN"));
            Console.WriteLine(dateinHindi);
            string dateinJapan = dateTime.ToString("F", new CultureInfo("ja-JP"));
            Console.WriteLine(dateinJapan);
            string dateinFrench = dateTime.ToString("F", new CultureInfo("fr-FR"));
            Console.WriteLine(dateinFrench);
            */
            /*
            CultureInfo currentculture = Thread.CurrentThread.CurrentCulture;
            Calendar c1 = currentculture.Calendar;
            Calendar calendar = new HijriCalendar();
            DateTime now = new DateTime(2022,01,09, calendar);
            Console.WriteLine(now.ToString("D"));
            */
            //sealed jeyword stops inheritence
            /*
            Console.WriteLine("Enter number between 1 and 7");
            int num = Convert.ToInt32(Console.ReadLine());
            switch (num)
            {
                case 1:
                    Console.WriteLine("Sunday"); break;
                case 2:
                    Console.WriteLine("Monday"); break;
                case 3:
                    Console.WriteLine("Tuesday"); break;
                case 4:
                    Console.WriteLine("Wednesday"); break;
                case 5:
                    Console.WriteLine("Thursday"); break;
                case 6:
                    Console.WriteLine("Friday"); break;
                case 7:
                    Console.WriteLine("Saturday"); break;
                default:
                    Console.WriteLine("Wrong choice");
                    break;
            */
            /*
            int x = 20, y = 10;
            var result = x > y ? "X is bigger" : 
                            x < y ? "X is smaller" : 
                                x == y ? "Both are equal" : "Nothing";
            Console.WriteLine(result);
            */
            /*
            int[] arr = { 1, 20, 3, 4, 5 };
            Console.WriteLine("Original");
            Console.WriteLine("Min:" + arr.Min());
            Console.WriteLine("max:" + arr.Max());
            Console.WriteLine("Sum"+arr.Sum());
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
            Console.WriteLine("After Deletion");
            var a = arr.Take(arr.Length-2).ToArray();
            foreach (var item in a)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("After sorting");
            Array.Sort(a);
            foreach (var item in a)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Min:"+a[0]);
            Console.WriteLine("max:"+a[a.Length-1]);
            Console.WriteLine("Sum");
            Console.WriteLine(a.Sum());
            */
        }
    }
}
