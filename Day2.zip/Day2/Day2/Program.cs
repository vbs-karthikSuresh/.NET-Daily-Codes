﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program
    {
        static int Add(params int[] val)
        {
            return val.Sum();
        }
        static float Add(params float[] val)
        {
            return val.Sum();
        }
        static void Add(params string[] val)
        {
            foreach (var item in val)
            {
                Console.WriteLine(item);
            }
        }
        static void Display(string CEO, string Manager, string Engineer)
        {
            Console.WriteLine("CEO: "+CEO);
        }
        public void Show(params Object[] val)
        {
            foreach(var item in val)
            {
                Console.WriteLine(item);
            }

        }
        static void Hello(string name="buddy")
        {
            Console.WriteLine("hello "+name);
        }
        static void Main(string[] args)
        {
            /*
            Dictionary<string, Int16> authorList = new Dictionary<string, Int16>();
            authorList.Add("Armin", 100);
            authorList.Add("Martin", 96);
            authorList.Add("Jon", 86);
            foreach (KeyValuePair<string,Int16> a in authorList)
            {
                Console.WriteLine($"Key: {a.Key}  value:{a.Value}");
            }
            authorList.Remove("Armin");
            Console.WriteLine("Removing");
            foreach (KeyValuePair<string, Int16> a in authorList)
            {
                Console.WriteLine($"Key: {a.Key}  value:{a.Value}");
            }
            Console.WriteLine(authorList.ContainsKey("Martin"));
            Console.WriteLine(authorList.ContainsValue(86));
            authorList.Clear();
            Console.WriteLine(authorList.Count);
            Dictionary<string, float> priceList = new Dictionary<string, float>();
            priceList.Add("CD", 7.99f);
            priceList.Add("Headphones", 199.99f);
            priceList.Add("DAC", 99.99f);
            foreach (KeyValuePair<string, float> a in priceList)
            {
                Console.WriteLine($"Key: {a.Key}  value:{a.Value}");
            }
            priceList.Remove("DAC");
            foreach (KeyValuePair<string, float> a in priceList)
            {
                Console.WriteLine($"Key: {a.Key}  value:{a.Value}");
            }
            Console.WriteLine(priceList.ContainsKey("CD"));
            Console.WriteLine(priceList.ContainsValue(199.99f));
            priceList.Clear();
            Console.WriteLine(priceList.Count);
            */
            /*
            string s = "TEST";
            char[] str = { 'T', 'E', 'S', 'T'};
            Console.WriteLine(s.CompareTo(str.ToString()));
            Console.WriteLine(s.Equals(str.ToString()));
            Console.WriteLine(s.Replace('S','X'));
            */
            /*
            StringBuilder s = new StringBuilder("hello", 50);
            Console.WriteLine(s);
            s.Append(" world");
            Console.WriteLine(s);
            s.AppendLine(" How are you?");
            Console.WriteLine(s);
            */
            /*
            int[][] arr = new int[4][];
            arr[0] = new int[1] { 1 };
            arr[1] = new int[2] { 2, 3 };
            arr[2] = new int[3] { 4, 5, 6 };
            arr[3] = new int[] { 7, 8, 9, 0, 312, 342 };
            foreach(var item in arr)
            {
                foreach(var i in item)
                {
                    Console.Write(i + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine("using for loop");
            for(int item=0; item < arr.Length; item++)
            {
                for(int i = 0; i < arr[item].Length; i++)
                {
                    Console.Write(arr[item][i] + " ");
                }
                Console.WriteLine();
            }
            */
            //Program p = new Program();
            //p.Show("karthik",21,"karthik@gmail.com","Bangalore");
            //Hello("karthik");
            //Hello();
            //Display(Engineer: "abc", Manager: "def", CEO: "karthik");
            //Console.WriteLine(Add(1, 2, 3, 4, 5, 6, 7, 8));
            //Console.WriteLine(Add(1.5f, 2.5f, 3.5f));
            //Add("abc", "def", "xyz");
                                         
        }
    }
}
    