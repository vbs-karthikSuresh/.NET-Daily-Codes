﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day9
{
    internal class Des: IDisposable
    {
        int real, img;
        public Des()
        {
            real = 0;
            img = 0;
        }
        public void SetValue(int x, int y)
        {
            real = x;
            img = y;
        }
        public void Display()
        {
            Console.WriteLine("r:" + real);
            Console.WriteLine("img:" + img);
        }
        public void Dispose()
        {
            Console.WriteLine("Dispose is called");
            Dispose(true);
            GC.SuppressFinalize(this);//Supresses destructor call

        }
        protected virtual void Dispose(bool dispose)
        {
            if (dispose)
            {
                Console.WriteLine("Cleaning all managed resources");
            }
        }
        ~Des()
        {
            Console.WriteLine("Destructor call");
            Dispose(false);
        }
    }
}
