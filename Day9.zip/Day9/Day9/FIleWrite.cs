﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day9
{
    internal class FIleWrite
    {
        public void WriteData(string text)
        {
            FileStream fs = new FileStream(@"C:\Users\Karthik Suresh\source\repos\Day9\Day9\myDetails.txt",FileMode.Append,FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(text);
            sw.Flush();
            sw.Close();
            fs.Close();
        }
        public void ReadData()
        {
            FileStream fs = new FileStream(@"C:\Users\Karthik Suresh\source\repos\Day9\Day9\myDetails.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            Console.WriteLine(sr.ReadToEnd());
            sr.Close();
            fs.Close();
        }
    }
}
