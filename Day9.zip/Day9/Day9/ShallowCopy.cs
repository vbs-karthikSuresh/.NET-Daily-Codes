﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day9
{
    internal class ShallowCopy: ICloneable 
    {
        public int Id { get; set; }
        public string  name { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
