﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Day9
{
    internal class Factory
    {
        private static int poolMaxSize = 2;
        private static readonly Queue objPool = new Queue(poolMaxSize);
        public Employee GetEmployee()
        {
            Employee emp = new Employee();
            if(Employee.counter>=poolMaxSize && objPool.Count > 1)
            {
                emp = RetriveFromPool();
                Console.WriteLine("Retrieve from Pool:"+Employee.counter+"  Pool Count:"+objPool.Count);
            }
            else
            {
                emp = GetNewEmployee();
                Console.WriteLine("Getting a new Employee:"+ Employee.counter+ "  Pool Count:" + objPool.Count);
            }
            return emp;
        }
        protected Employee RetriveFromPool()
        {
            Employee emp;
            if (objPool.Count > 0)
            {
                emp = (Employee)objPool.Dequeue();
                Employee.counter--;
                Console.WriteLine("Retrive from pool:"+Employee.counter);
            }
            else
            {
                emp = new Employee();
            }
            return emp;
        }
        private Employee GetNewEmployee()
        {
            Employee emp = new Employee();
            objPool.Enqueue(emp);
            return emp;
        }
    }
    internal class Employee
    {
        public static int counter = 0;
        public Employee()
        {
            ++counter;
        }
        private string firstName;
        private string FirstName
        {
            get { return firstName; }
            set{firstName = value;}
           
        }

    }
}
