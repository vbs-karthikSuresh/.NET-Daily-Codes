﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day9
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Des d = new Des();
            d.SetValue(1, 2);
            d.Display();
            d.Dispose();
            */
            /*
            Factory f = new Factory();
            f.GetEmployee();
            f.GetEmployee();
            f.GetEmployee();
            f.GetEmployee();
            f.GetEmployee();
            */
            /*
            ShallowCopy s1 = new ShallowCopy();
            s1.Id = 101;
            s1.name = "Karthik";
            Console.WriteLine(s1.Id + " " + s1.name);
            ShallowCopy s2 = s1;
            s2.Id = 102;
            Console.WriteLine(s1.Id + " " + s1.name);
            Console.WriteLine(s2.Id + " " + s2.name);
            */
            /*
            ShallowCopy s1 = new ShallowCopy();
            s1.Id = 101;
            s1.name = "Karthik";
            Console.WriteLine(s1.Id + " " + s1.name);
            ShallowCopy s2 = (ShallowCopy)s1.Clone();
            s2.Id = 102;
            Console.WriteLine(s1.Id+" "+s1.name);
            Console.WriteLine(s2.Id + " " + s2.name);
            */
            FIleWrite f = new FIleWrite();
            f.WriteData("\nHello");
            f.ReadData();
        }
    }
}
