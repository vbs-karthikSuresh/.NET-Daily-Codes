﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7
{
    public class OutOfStockException : Exception
    {
        public OutOfStockException(string message) : base(message)
        {

        }
    }
    class Order
    {
        int order = Convert.ToInt32(Console.ReadLine());
        public void show()
        {
            if (order > 5)
            {
                throw (new OutOfStockException("order is Out of stock"));
            }
            else
            {
                Console.WriteLine(order);
            }
        }
    }
}
