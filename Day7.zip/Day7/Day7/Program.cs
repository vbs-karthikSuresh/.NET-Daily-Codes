﻿using System;

namespace Day7
{
    public delegate void DelMethod(int x, int y);
    //public delegate void DelMethod();
    class Program
    {
        /*
        public delegate void DelMethod();
        public static void Display()
        {
            Console.WriteLine("Inside Display");
        }
        public static void Show()
        {
            Console.WriteLine("Inside Show");
        }
        public void Print()
        {
            Console.WriteLine("Inside Print");
        }
        */
        
        public void Add(int x,int y)
        {
            Console.WriteLine("Sum:"+(x+y));
        }
        public void Subtract(int x,int y)
        {
            Console.WriteLine("Difference:"+(x-y));
        }
        public static string GetString()
        {
            return "Hello";
        }
        public static void SetObject(Object val1)
        {

        }
        public static void SetString(String val2)
        {

        }
        static void Main(string[] args)
        {
            /*
            int[] arr = { 1, 2, 3 };
            //int[] arr = { 1, 0, 3 };
            try
            {
                for(int i = 0; i < arr.Length; i++)
                {
                    //Console.WriteLine(arr[i]/arr[i+1]);
                    Console.WriteLine(arr[i]);
                }
            }
            catch(IndexOutOfRangeException e)
            {
                Console.WriteLine(e.Message+ " "+ e.StackTrace);
            }
            catch(DivideByZeroException e)
            {
                Console.WriteLine(e.Message + " " + e.StackTrace);
            }
            finally
            {
                Console.WriteLine("Finnally Block");
            }
            */
            //Console.WriteLine("User defined exception");
            /*
            Temperature temperature = new Temperature();
            try
            {
                temperature.show();
            }
            catch(TempIsZeroException e)
            {
                Console.WriteLine("Temp is zero\n"+e.Message);
            }
            Console.WriteLine("Hello");
            */
            /*
            Age a = new Age();
            Console.WriteLine("Enter Age");
            try
            {
                a.show();
            }
            catch(AgeIsLessException e)
            {
                Console.WriteLine(e.Message);
            }
            */
            /*
            Console.WriteLine("Enter Order");
            Order a = new Order();
            try
            {
                
                a.show();
            }
            catch (OutOfStockException e)
            {
                Console.WriteLine(e.Message + e.StackTrace);
            }
            */
            /*
            Console.WriteLine("Single cast delegate");
            DelMethod del1 = Program.Show;
            DelMethod del2 = new DelMethod(Program.Display);
            Program p1 = new Program();
            DelMethod del3 = p1.Print;
            del1();
            del2();
            del3();
            */
            /*
            Program p1 = new Program();
            DelMethod del1 = p1.Add;
            del1 += p1.Subtract;
            del1(10,5);//for both operations
            del1 -= p1.Subtract;
            Console.WriteLine("Removing subtract");
            del1(10, 5);
            DelMethod del = delegate (int x, int y)
            {
                 Console.WriteLine("Annonyomous Multiplication:"+(x*y));
            };
            del1(10,20);
            del1 += del;
            Console.WriteLine("Finally");
            del1(50, 30);
            */
            Console.WriteLine("Covariance and Contravariance");
            Func<object> del = GetString;
            Console.WriteLine(del());
            Action<string> del1 = SetObject;
            //Contravarinace
            Func<string> del2 = GetString;
            //Implicit conversion of generic delegates
            Func<object> del3 = del2;
        }
    }
}
