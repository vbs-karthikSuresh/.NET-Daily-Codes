﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7
{
    public class TempIsZeroException:Exception
    {
        public TempIsZeroException(string message):base(message)
        {

        }
    }
    class Temperature
    {
        int temperature = 0;
        public void show()
        {
            if (temperature == 0)
            {
                throw (new TempIsZeroException("Zero temperature found"));
            }
            else
            {
                Console.WriteLine(temperature);
            }
        }
    }
}
