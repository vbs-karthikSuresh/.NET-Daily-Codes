﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7
{
    public class AgeIsLessException : Exception
    {
        public AgeIsLessException(string message) : base(message)
        {

        }
    }
    class Age
    {
        
        int age = Convert.ToInt32(Console.ReadLine());
        public void show()
        {
            if (age<20)
            {
                throw (new AgeIsLessException("Age is less than 20"));
            }
            else
            {
                Console.WriteLine(age);
            }
        }
    }
}
