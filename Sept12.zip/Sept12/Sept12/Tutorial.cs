﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sept12
{
    [Serializable]//Declarative Tag
    internal class Tutorial
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
