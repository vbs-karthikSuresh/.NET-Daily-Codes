﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Sept12
{
    /*
    public class MyThread
    {
        public static void Thread1Display()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("First Thread "+i);
            }
        }
        public static void Thread2Display()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Second Thread "+i);
            }
        }
    }
    */
    class Program
    {
        public static void Print()
        {
            //Console.WriteLine("Starting Thread");
            for (int i = 11; i < 20; i++)
            {
                Console.WriteLine("Worker Thread " + i);
                Thread.Sleep(100);
            }
        }
        static void Main(string[] args)
        {
            /*
            Tutorial t1 = new Tutorial();
            t1.ID = 1;
            t1.Name = "Karthik Suresh";
            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream(@"C:\Users\Karthik Suresh\source\repos\Sept12\Sept12\Serialization.txt",FileMode.OpenOrCreate,FileAccess.ReadWrite);
            //Searliazing the object
            formatter.Serialize(stream,t1);         
            Console.WriteLine("Objects has been searlizsed");
            stream.Close();
            Stream stream1 = new FileStream(@"C:\Users\Karthik Suresh\source\repos\Sept12\Sept12\Serialization.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            Tutorial t2 = (Tutorial)formatter.Deserialize(stream1);
            Console.WriteLine(t2.ID+" "+t2.Name);        
            stream1.Close();
            */
            //Console.WriteLine("Multi Threading");
            //for non static methonds
            //MyThread thread = new MyThread();
            //Thread th = new Thread(new ThreadStart(thread.ThreadDisplay));
            //th.Start();
            /*
            Thread th1 = new Thread(MyThread.Thread1Display);
            th1.Start();
            Thread th2 = new Thread(MyThread.Thread2Display);            
            th2.Start();
            */
            /*
            Thread th = new Thread(new ThreadStart(Program.Print));
            th.Start();
            
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine("Main Thread "+i);
                Thread.Sleep(200);
            }
            */
            /*
            Thread th = new Thread(new ThreadStart(Program.Print));
            Console.WriteLine("Alive: "+th.IsAlive);
            Console.WriteLine("State: "+th.ThreadState);
            th.Start();
            Console.WriteLine("After Starting");
            Console.WriteLine("Alive: " + th.IsAlive);
            Console.WriteLine("State: " + th.ThreadState);
            th.Suspend();
            Console.WriteLine("After Suspending");
            Console.WriteLine("Alive: " + th.IsAlive);
            Console.WriteLine("State: " + th.ThreadState);
            th.Resume();
            Console.WriteLine("After Resuming");
            Console.WriteLine("Alive: " + th.IsAlive);
            Console.WriteLine("State: " + th.ThreadState);
            */


        }
    }
}
