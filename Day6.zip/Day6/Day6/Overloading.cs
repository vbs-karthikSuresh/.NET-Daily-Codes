﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6
{
    class Overloading
    {
        public int num1;
        public float num2;
        public Overloading(int num1, float num2)
        {
            this.num1 = num1;
            this.num2 = num2;
        }
        public static Overloading operator +(Overloading o1, Overloading o2)
        {
            Overloading res = new Overloading(0,0);
            res.num1 = o1.num1 + o2.num1;
            res.num2 = o1.num2 + o2.num2;
            return res;
        }
        public void Print()
        {
            Console.WriteLine("Num1 "+num1);
            Console.WriteLine("Num2 :"+num2);
        }
    }
}
