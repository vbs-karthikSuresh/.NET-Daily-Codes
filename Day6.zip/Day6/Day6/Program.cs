﻿using System;

namespace Day6
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Overloading op1 = new Overloading(10, 20.325f);
            Overloading op2 = new Overloading(30, 40.243f);
            Overloading op3 = new Overloading(0, 0f);
            Console.WriteLine("OP1");
            op1.Print();
            Console.WriteLine("OP2");
            op2.Print();
            Console.WriteLine("OP3");
            op3.Print();
            Console.WriteLine("+ Overloading");
            op3 = op1 + op2;
            op3.Print();
            */
            /*
            Equal e1 = new Equal { id = 1, name = "Karthik", address = "Bangalore" };
            Equal e2 = new Equal { id = 1, name = "Karthik", address = "Bangalore" };
            Console.WriteLine(e1==e2);
            Console.WriteLine(e1 == e1);
            Console.WriteLine(e1.Equals(e2));
            Console.WriteLine(e1.Equals(e1));
            Console.WriteLine(Object.ReferenceEquals(e1,e2));
            Console.WriteLine(e1.);
            */
            /*
            StructEqual e1 = new StructEqual { id = 1, name = "Karthik" };
            StructEqual e2 = new StructEqual { id = 1, name = "Karthik" };
            string s1 = "HELLO";
            string s2 = "HELLO";
            //Console.WriteLine(e1 == e2); its value type and not reference type    
            //Console.WriteLine(e1.Equals(e2));
            //Console.WriteLine(Object.ReferenceEquals(e1, e1));// Can't pass value type to this function because this  structure is value type
            
            Console.WriteLine("STrings");
            Console.WriteLine(s1==s2);
            Console.WriteLine(s1.CompareTo(s2));
            Console.WriteLine(s1.Equals(s2));
            Console.WriteLine(Object.ReferenceEquals(s1, s2));
            Console.WriteLine(s1.GetHashCode()==s2.GetHashCode());
            
            Less than zero – This instance precedes strB.
            Zero – This instance has the same position in the sort order as strB.
            Greater than zero – This instance follows strB. -or- strB is null.
            */
                     

        }
    }
}
