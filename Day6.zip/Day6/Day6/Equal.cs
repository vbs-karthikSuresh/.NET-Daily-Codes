﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6
{
    internal class Equal
    {
        public string name { get; set; }
        public int id { get; set; }
        public string address { get; set; }

    }
    internal struct StructEqual
    {
        public string name { get; set; }
        public int id { get; set; }
    }

}
