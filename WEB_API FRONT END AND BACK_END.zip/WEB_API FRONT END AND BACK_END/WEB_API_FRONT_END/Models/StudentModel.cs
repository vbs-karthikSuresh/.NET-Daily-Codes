﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WEB_API_FRONT_END.Models
{
    public class StudentModel
    {
        [Display(Name="ID")]
        public int ID { get; set; }
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Display(Name = "Email")]
        public string Email { get; set; }
        [Display(Name = "Course")]
        public string Course { get; set; }
        [Display(Name = "Contact")]
        public string Contact { get; set; }
    }
}