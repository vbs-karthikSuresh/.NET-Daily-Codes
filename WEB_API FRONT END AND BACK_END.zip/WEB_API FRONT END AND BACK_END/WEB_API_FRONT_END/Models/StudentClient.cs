﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;


namespace WEB_API_FRONT_END.Models
{
    public class StudentClient
    {
        private string baseURL= "https://localhost:44337/api/";
        public IEnumerable<StudentModel> Find()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(baseURL);
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage message = client.GetAsync("Students").Result;
                if (message.IsSuccessStatusCode)
                {
                   return message.Content.ReadAsAsync<IEnumerable<StudentModel>>().Result;
                }
                return null;
            }
            catch(Exception)
            {
                return null;
            }
        }
        public StudentModel Find(string id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(baseURL);
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage message = client.GetAsync("Students/" + id).Result;
                if (message.IsSuccessStatusCode)
                {
                    return message.Content.ReadAsAsync<StudentModel>().Result;
                }
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public bool Delete(int id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(baseURL);
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage message = client.DeleteAsync("Students/" + id).Result;
                return message.IsSuccessStatusCode;            
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}