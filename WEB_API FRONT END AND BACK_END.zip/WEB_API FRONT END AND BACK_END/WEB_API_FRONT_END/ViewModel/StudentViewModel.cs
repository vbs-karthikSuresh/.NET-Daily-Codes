﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WEB_API_FRONT_END.Models;

namespace WEB_API_FRONT_END.ViewModel
{
    public class StudentViewModel
    {
        public StudentModel student { get; set; }

    }
}