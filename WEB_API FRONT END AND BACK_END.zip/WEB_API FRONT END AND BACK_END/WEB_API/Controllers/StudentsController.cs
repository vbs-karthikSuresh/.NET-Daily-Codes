﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WEB_API;

namespace WEB_API.Controllers
{
    public class StudentsController : ApiController
    {
        private Freshers_Training2022Entities db = new Freshers_Training2022Entities();

        // GET: api/Students
        public IQueryable<Karthiks_StudentsEF> GetKarthiks_StudentsEF()
        {
            return db.Karthiks_StudentsEF;
        }

        // GET: api/Students/5
        [ResponseType(typeof(Karthiks_StudentsEF))]
        public IHttpActionResult GetKarthiks_StudentsEF(int id)
        {
            Karthiks_StudentsEF karthiks_StudentsEF = db.Karthiks_StudentsEF.Find(id);
            if (karthiks_StudentsEF == null)
            {
                return NotFound();
            }

            return Ok(karthiks_StudentsEF);
        }

        // PUT: api/Students/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutKarthiks_StudentsEF(int id, Karthiks_StudentsEF karthiks_StudentsEF)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != karthiks_StudentsEF.ID)
            {
                return BadRequest();
            }

            db.Entry(karthiks_StudentsEF).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Karthiks_StudentsEFExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Students
        [ResponseType(typeof(Karthiks_StudentsEF))]
        public IHttpActionResult PostKarthiks_StudentsEF(Karthiks_StudentsEF karthiks_StudentsEF)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Karthiks_StudentsEF.Add(karthiks_StudentsEF);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = karthiks_StudentsEF.ID }, karthiks_StudentsEF);
        }

        // DELETE: api/Students/5
        [ResponseType(typeof(Karthiks_StudentsEF))]
        public IHttpActionResult DeleteKarthiks_StudentsEF(int id)
        {
            Karthiks_StudentsEF karthiks_StudentsEF = db.Karthiks_StudentsEF.Find(id);
            if (karthiks_StudentsEF == null)
            {
                return NotFound();
            }

            db.Karthiks_StudentsEF.Remove(karthiks_StudentsEF);
            db.SaveChanges();

            return Ok(karthiks_StudentsEF);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Karthiks_StudentsEFExists(int id)
        {
            return db.Karthiks_StudentsEF.Count(e => e.ID == id) > 0;
        }
    }
}