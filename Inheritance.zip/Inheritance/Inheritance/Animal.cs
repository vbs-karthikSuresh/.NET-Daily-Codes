﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    /*
    internal class Animal
    {
        protected string Color = "Yellow";
        public virtual void Speak()
        {
            Console.WriteLine("Parent");
            Console.WriteLine("Animal Noise");
        }
    }
    internal class Dog : Animal
    {
        string color = "Brown";
        public void ShowColor()
        {
            Console.WriteLine("Base "+base.Color);
            Console.WriteLine("Child "+color);
        }
        public override void Speak()
        {
            Console.WriteLine("Child");
            Console.WriteLine("Woof!");
            base.Speak();
            
        }
    }
    */
    interface IDomesticAnimal
    {
        //We canot not define data members  
        //All methods are by default abstract and public  
        string Colortype();
        void NoLegs();
        int Weight();
        void Age();
        void Food_Type();
        public int No_of_Kids { get; set; }
    }
    abstract class Animal
    {
        public abstract void speak();
        //{
        //We cant provide function defination 

        //    Console.WriteLine("Testing "); 

        //} 
        public void AnimalLanguage()

        {

            Console.WriteLine("ZZZZZ....ZZZZ...Z.Z.Z.Z");

        }
    }
    class Dog : Animal, IDomesticAnimal
    {
        public int No_of_Kids { get; set; }
        public void Age()

        {

            throw new NotImplementedException();

        }
        public string Colortype()

        {

            throw new NotImplementedException();

        }
        public void Food_Type()

        {

            throw new NotImplementedException();

        }
        public void NoLegs()

        {

            throw new NotImplementedException();

        }
        public override void speak()

        {

            Console.WriteLine(" The Dog Says : Woof Woof ....");

        }
        public void Weight()

        {

            throw new NotImplementedException();

        }
        int IDomesticAnimal.Weight()

        {

            throw new NotImplementedException();

        }

    }
    class Cat : Animal, IDomesticAnimal

    {
        public int No_of_Kids { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public void Age()

        {

            throw new NotImplementedException();

        }
        public string Colortype()

        {

            throw new NotImplementedException();

        }
        public void Food_Type()

        {

            throw new NotImplementedException();

        }
        public void NoLegs()

        {

            throw new NotImplementedException();

        }
        public override void speak()

        {

            Console.WriteLine(" The Cat Says Meow .. Meow....");

        }
        public void Weight()

        {

            throw new NotImplementedException();

        }
        int IDomesticAnimal.Weight()
        {

            throw new NotImplementedException();

        }
    }
}