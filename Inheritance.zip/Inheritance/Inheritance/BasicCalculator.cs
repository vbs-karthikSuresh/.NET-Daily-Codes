﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    //Multiple Inheritance
    internal interface BasicCalculator
    {
        public int Add(int a, int b);
        public int Sub(int a, int b);
    }
    interface ScientificCalculator
    {
        public float Add(float a, float b);
        public float Subtract(float a, float b);
    }
    class Calculation : BasicCalculator, ScientificCalculator
    {
        public int Add(int a, int b)
        {
            Console.WriteLine("Basic Calculator");
            return a + b;
        }

        public float Add(float a, float b)
        {
            Console.WriteLine("Scientific calculator");
            return a + b;
        }

        public int Sub(int a, int b)
        {
            Console.WriteLine("Basic Calculator");
            return a - b;
        }

        public float Subtract(float a, float b)
        {
            Console.WriteLine("Scientific calculator");
            return a - b;
        }
    }
}
