﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Practice
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Stack<int> s = new Stack<int>();
            s.Push(10);
            s.Push(20);
            s.Push(30);
            Console.WriteLine("Count:"+s.Count());
            Console.WriteLine("Current:"+s.Peek());
            s.Pop();
            Console.WriteLine("Current:" + s.Peek());
            Console.WriteLine("Count:" + s.Count());
            */
            /*
            Stack s = new Stack();
            s.Push(10);
            s.Push(20.5);
            s.Push("30");
            Console.WriteLine("Count:" + s.Count);
            Console.WriteLine("Current:" + s.Peek());
            s.Pop();
            Console.WriteLine("Current:" + s.Peek());
            Console.WriteLine("Count:" + s.Count);
            */
            /*
            Queue<int> q = new Queue<int>();
            q.Enqueue(10);
            q.Enqueue(20);
            q.Enqueue(30);
            q.Enqueue(40);
            q.Enqueue(50);
            Console.WriteLine("Count:" + q.Count);
            Console.WriteLine("Current:" + q.Peek());
            q.Dequeue();
            q.Dequeue();
            Console.WriteLine("Count:" + q.Count);
            Console.WriteLine("Current:" + q.Peek());
            */
            /*
            Queue q = new Queue();
            q.Enqueue(10);
            q.Enqueue(20.35);
            q.Enqueue("30ABC");
            q.Enqueue(408465);
            q.Enqueue(5087532.675);
            Console.WriteLine("Count:" + q.Count);
            Console.WriteLine("Current:" + q.Peek());
            q.Dequeue();
            q.Dequeue();
            Console.WriteLine("Count:" + q.Count);
            Console.WriteLine("Current:" + q.Peek());
            */
            /*
            HashSet<int> q = new HashSet<int>();
            q.Add(10);
            q.Add(20);
            q.Add(30);
            q.Add(40);
            q.Add(50);
            Console.WriteLine("Hash set 1");
            foreach (var ele in q)
            {
                Console.WriteLine(ele);
            }
            Console.WriteLine("Count:" + q.Count);
            HashSet<int> q1 = new HashSet<int>();
            q1.Add(100);
            q1.Add(2);
            q1.Add(30);
            q1.Add(4);
            q1.Add(50);
            Console.WriteLine("Hash set 2");
            foreach (var ele in q1)
            {
                Console.WriteLine(ele);
            }
            q1.IntersectWith(q);
            Console.WriteLine("Hash set 2 after intersection");
            foreach (var item in q1)
            {
                Console.WriteLine(item);
            }
            q.ExceptWith(q1);
            Console.WriteLine("Hash set 1 after exceptwith");
            foreach (var item in q)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Removing 10");
            q.Remove(10);
            foreach (var item in q)
            {
                Console.WriteLine(item);
            }
            */
            /*
            Hashtable h = new Hashtable();
            h.Add(1, 100);
            h.Add(2, "10abc");
            h.Add(3, 4.453);
            h.Add(6, 12345);
            h.Add(4, 837469.834734);
            h.Add(250, "India");
            h.Add("ABC", "DEF");
            h.Add(true, "123455");
            foreach (DictionaryEntry item in h)
            {
                Console.WriteLine($"key:{item.Key}  value: {item.Value}");
            }
            h.Remove(2);
            Console.WriteLine("Removing 2");
            foreach (DictionaryEntry item in h)
            {
                Console.WriteLine($"key:{item.Key}  value: {item.Value}");
            }
            */
            /*
            Dictionary<string, Int16> authorList = new Dictionary<string, Int16>();
            authorList.Add("Armin", 100);
            authorList.Add("Martin", 96);
            authorList.Add("Jon", 86);
            foreach (KeyValuePair<string,Int16> a in authorList)
            {
                Console.WriteLine($"Key: {a.Key}  value:{a.Value}");
            }
            authorList.Remove("Armin");
            Console.WriteLine("Removing");
            foreach (KeyValuePair<string, Int16> a in authorList)
            {
                Console.WriteLine($"Key: {a.Key}  value:{a.Value}");
            }
            Console.WriteLine(authorList.ContainsKey("Martin"));
            Console.WriteLine(authorList.ContainsValue(86));
            authorList.Clear();
            Console.WriteLine(authorList.Count);
            Dictionary<string, float> priceList = new Dictionary<string, float>();
            priceList.Add("CD", 7.99f);
            priceList.Add("Headphones", 199.99f);
            priceList.Add("DAC", 99.99f);
            foreach (KeyValuePair<string, float> a in priceList)
            {
                Console.WriteLine($"Key: {a.Key}  value:{a.Value}");
            }
            priceList.Remove("DAC");
            foreach (KeyValuePair<string, float> a in priceList)
            {
                Console.WriteLine($"Key: {a.Key}  value:{a.Value}");
            }
            Console.WriteLine(priceList.ContainsKey("CD"));
            Console.WriteLine(priceList.ContainsValue(199.99f));
            priceList.Clear();
            Console.WriteLine(priceList.Count);
            */
        }
    }
}
